package p2;

public interface CSVSerializable {
    String toCSV();
    void fromCSV(String csv);
}
