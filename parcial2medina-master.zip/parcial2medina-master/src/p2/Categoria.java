package p2;

public enum Categoria {
    CIENCIA,
    LITERATURA,
    TECNOLOGIA,
    ARTE,
    HISTORIA,
    ENTRETENIMIENTO
}
